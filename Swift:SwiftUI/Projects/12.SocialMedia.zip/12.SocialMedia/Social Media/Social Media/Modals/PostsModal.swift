//
//  PostsVC.swift
//  Social Media
//
//  Created by M_955328 on 3/3/22.
//

import Foundation

struct PostsModal: Decodable{
    var userId: Int?
    var id: Int?
    var title: String
    var body: String
}

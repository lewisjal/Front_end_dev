//
//  UsersVCExtension.swift
//  Social Media
//
//  Created by M_955328 on 3/7/22.
//

//import Foundation
//extension UserViewController: UsersTableViewCellDelegate{
////        func didTapUserImageButton(){
////            guard let ProfileDetailVC = storyboard?.instantiateViewController(withIdentifier: "profiles") as? ProfileDetailVC else{
////                return
////            }
////            
////            ProfileDetailVC.users = users
////            navigationController?.pushViewController(ProfileDetailVC, animated: true)
////        }
//}

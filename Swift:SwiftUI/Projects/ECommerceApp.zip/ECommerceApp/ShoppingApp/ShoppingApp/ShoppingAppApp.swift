//
//  ShoppingAppApp.swift
//  ShoppingApp
//
//  Created by M_955328 on 3/28/22.
//

import SwiftUI

@main
struct ShoppingAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}

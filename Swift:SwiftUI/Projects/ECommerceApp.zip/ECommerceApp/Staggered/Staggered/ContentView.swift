//
//  ContentView.swift
//  StaggeredGrid
//
//  Created by M_955328 on 3/31/22.
//

import SwiftUI

struct ContentView: View {
    var body: some View {
        Home()
    }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

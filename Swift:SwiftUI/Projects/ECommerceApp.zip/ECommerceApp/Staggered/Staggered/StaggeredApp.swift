//
//  StaggeredGridApp.swift
//  StaggeredGrid
//
//  Created by M_955328 on 3/31/22.
//

import SwiftUI

@main
struct StaggeredGridApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
